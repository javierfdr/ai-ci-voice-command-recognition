function  gau_hmm_init_train(traininglist_filename,model_filename,MODEL_NO,STATE_NO, dim )
if nargin == 0
    traininglist_filename='training_list.mat' ;
    model_filename='models.mat';
    MODEL_NO=11;
    STATE_NO=4;
    dim=12;
end
MIN_SELF_TRANSITION_COUNT=0;
load(traininglist_filename,'list');


% allocate mean, var vectors, transition prob. for the of models
mean_vec_i_m=zeros(dim,STATE_NO,MODEL_NO);
var_vec_i_m=zeros(dim,STATE_NO,MODEL_NO);
A_i_m=zeros(STATE_NO,MODEL_NO);

vector_sums_i_m=zeros(dim,STATE_NO,MODEL_NO);
var_vec_sums_i_m=zeros(dim,STATE_NO,MODEL_NO);
fr_no_i_m=zeros(STATE_NO,MODEL_NO);
self_tr_fr_no_i_m=zeros(STATE_NO,MODEL_NO);

utterance_no=size(list,1);
total_fr_no=0;
for k=1:utterance_no
    filename=list{k,2};
    m=list{k,1}; % word ID
    fid=fopen(filename,'r');
    fseek(fid, 12, 'bof'); % skip the 12-byte HTK header
    c=fread(fid,'float','b');
    fclose(fid);
    fr_no=length(c)/dim;
    total_fr_no=total_fr_no+fr_no;
    c=reshape(c,dim,fr_no);
    
    for i=1:STATE_NO
        begin_fr=round(  fr_no*(i-1) /STATE_NO)+1;
        end_fr=round( fr_no*i /STATE_NO);
        seg_length=end_fr-begin_fr+1;
        vector_sums_i_m(:,i,m) = vector_sums_i_m(:,i,m) + sum(c(:,begin_fr:end_fr),2);
        var_vec_sums_i_m(:,i,m) = var_vec_sums_i_m(:,i,m) +  sum( c(:,begin_fr:end_fr).*c(:,begin_fr:end_fr) , 2);
        fr_no_i_m(i,m)=fr_no_i_m(i,m)+seg_length;
        self_tr_fr_no_i_m(i,m)= self_tr_fr_no_i_m(i,m) + seg_length-1;
    end %for s=1:STATE_NO
end % for k=1:utterance_no

for m=1:MODEL_NO
    for i=1:STATE_NO
        mean_vec_i_m(:,i,m) = vector_sums_i_m(:,i,m) / fr_no_i_m(i,m);
        var_vec_i_m(:,i,m) = var_vec_sums_i_m(:,i,m) / fr_no_i_m(i,m);
        A_i_m(i,m)=(self_tr_fr_no_i_m(i,m)+MIN_SELF_TRANSITION_COUNT)/(fr_no_i_m(i,m)+2*MIN_SELF_TRANSITION_COUNT);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                   tying of cov. matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
overall_var_vec=sum(sum(var_vec_sums_i_m(:,:,:),3 ),2)/sum(sum(fr_no_i_m,2 ),1);
for m=1:MODEL_NO
    for i=1:STATE_NO
        var_vec_i_m(:,i,m)=overall_var_vec;
    end
end
%%%%%%%%%%%%%%%%            end of cov. matrices tying

save(model_filename, 'mean_vec_i_m', 'var_vec_i_m', 'A_i_m');
fprintf('init. train complete \n');



