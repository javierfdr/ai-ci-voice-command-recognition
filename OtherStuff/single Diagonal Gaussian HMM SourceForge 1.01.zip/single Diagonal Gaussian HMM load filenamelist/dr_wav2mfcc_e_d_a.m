
function dr_wav2mfcc_e_d_a(indir,in_filter,outdir,out_ext,outfile_format,frame_size_sec,frame_shift_sec,use_hamming,pre_emp,bank_no,cep_order,lifter,delta_win_weight)
  if  indir(end) == '/' || indir(end) == '\'
      indir=indir(1:(end-1));
  end
  if  outdir(end) == '/' || outdir(end) == '\'
      ourdir=outdir(1:(end-1));
  end
  
  if exist(outdir) ~=7
      mkdir(outdir);
  end
  
  filelist=dir(indir);
  filelist_len=length(filelist);
  
  % filelist(1)='.'        % filelist(2)='..'  should be excluded
  for k=3:filelist_len
      [pathstr,filenamek,ext,versn] = fileparts(filelist(k).name);
      if filelist(k).isdir
          dr_wav2mfcc_e_d_a([indir filesep filenamek],in_filter,[outdir filesep filenamek],out_ext,outfile_format,frame_size_sec,frame_shift_sec,use_hamming,pre_emp,bank_no,cep_order,lifter,delta_win_weight);
      else
          if regexp(filelist(k).name,in_filter)
              infilename=fullfile(indir, filelist(k).name);
              outfilename=[outdir filesep filenamek out_ext];
              fwav2mfcc_e_d_a(infilename,outfilename,outfile_format,frame_size_sec,frame_shift_sec,use_hamming,pre_emp,bank_no,cep_order,lifter,delta_win_weight);
          end
      end
  end
