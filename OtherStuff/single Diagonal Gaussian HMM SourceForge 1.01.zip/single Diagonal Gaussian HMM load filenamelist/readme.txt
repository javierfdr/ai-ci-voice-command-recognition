This readme document is for version 1.01.

The entry point for this package is ��main_train_test_EM.m��. In that script file, you may need to modify several parameters for the recognition system such as DIM (the dimension of feature vector), MODEL_NO, STATE_NO, and ITERATION_END (which is used to determine the number of training iterations).
��	
Before you start to use the programs, you should first prepare the training and testing data. An excerpt of TIDIGITS database can be obtained from http://cronos.rutgers.edu/~lrr/speech%20recognition%20course/databases/isolated_digits_ti_train_endpt.zip and http://cronos.rutgers.edu/~lrr/speech%20recognition%20course/databases/isolated_digits_ti_test_endpt.zip. The root directory for the training data, isolated_digits_ti_train_endpt, and the root directory for test data, isolated_digits_ti_test_endpt, should be placed under the ��wav�� directory so that we do not need to modify ��main_train_test_EM.m�� to run that program.
��	
To prepare your own data, you can modify the Matlab script file ��dr_wav2mfcc_e_d_a_gen.m�� for extracting the feature vector sequence from your own waveform data. You need to create a .mat file containing a list of training data and another .mat file containing a list of testing data, where the first element of a record represents the word id (in integer) and the second element is the path of the data file. Example Matlab script files for creating training and testing list files are ��generate_isolated_digits_ti_training_list_mat.m�� and ��generate_isolated_digits_ti_testing_list_mat.m��, respectively.
��	
The feature file format used in this version is compactable with the HTK format.
