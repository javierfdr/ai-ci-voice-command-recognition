
function [Fopt, varargout]=fun_viterbi_hmm(V, mean_vec_i, var_vec_i, A_i)
[dim ,N]=size(mean_vec_i);
[dim , T]=size(V);
P=cell(N,T);
f=ones(N,T)*(-inf);

%%%%%%%%%%%%  t=1  %%%%%%%%%%%%%%%%%%%%
for i=1:N
        P{i,1}=i;
end
t=1;i=1;
f(i,t)=logDiagGaussian(V(:,t),mean_vec_i(:,i),var_vec_i(:,i));
% other f(i,t) terms have been set to -inf

%%%%%%%%%%%%  t=2:T   %%%%%%%%%%%%%
for t=2:T
    i=1;
        f(i,t)=f(i,t-1)+log(A_i(i))+ logDiagGaussian(V(:,t),mean_vec_i(:,i),var_vec_i(:,i) );
    for i=2:N % pi=previous i
        [f(i,t), pi] = max(  [ f(i-1,t-1) + log(1-A_i(i-1))  ,  f(i,t-1) + log(A_i(i)) ] ); 
        f(i,t)=f(i,t)+logDiagGaussian(V(:,t),mean_vec_i(:,i),var_vec_i(:,i) );
        P{i,t}=[P{i+pi-2,t-1}  i ];  
   end
end

%%%%%%%%%%%%%% optimal path  %%%%%%%%%%%%%
Fopt=  f(N,T) + log(1-A_i(N)) ;
if nargout > 1
     varargout(1)= { P{N,T} };
end
end



  