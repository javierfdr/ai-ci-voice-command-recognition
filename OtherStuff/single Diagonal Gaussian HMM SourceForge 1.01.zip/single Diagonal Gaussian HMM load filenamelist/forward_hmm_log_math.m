%log_pr: log prob. of forward function
%varargout(1)= logfw 
%varargout(2)=  logObsevation_i_t
function [log_pr, varargout]=forward_hmm_log_math(V, mean_vec_i, var_vec_i,  A_i  )
[dim , N]=size(mean_vec_i);
[dim2 , T]=size(V);
logObsevation_i_t=zeros(N,T);
for t=1:T
    for i=1:N
        logObsevation_i_t(i,t)=logDiagGaussian(V(:,t),mean_vec_i(:,i),var_vec_i(:,i));
    end
end
%%%%%%%%%%%%%%  log  forward probability        %%%%%%%%%%%%%
logfw=ones(N,T)*(-inf);
%%%%%%%%%%%%%%  t=1, i=1:N   %%%%%%%%%%%%%
t=1;
logfw(1,1)=logObsevation_i_t(1,1);
% logfw(i,1)=-inf  for  i != 1  have already been initialized during array allocation

%%%%%%%%%%%%  t=2:T, i=1:N   %%%%%%%%%%%%%
for t=2:T
    i=1;
        logfw(i,t)=logfw(i,t-1) + log(A_i(i))+logObsevation_i_t(i,t);
   for i=2:N
        logfw(i,t)= logSum(  [ (logfw(i-1,t-1) +log(1-A_i(i-1)) ) , (logfw(i,t-1) + log(A_i(i))) ] ) + logObsevation_i_t(i,t);      
   end   
end %for t=2:T
   
 log_pr=logfw(N,T) + log(1-A_i(N));

if nargout > 1
    varargout(1)= {logfw}; 
end
if nargout > 2
    varargout(2)= {logObsevation_i_t}; 
end

end % of function
