function [total_log_prob, total_fr_no]=gau_hmm_EM_reestimation(traininglist_filename,model_filename_old, model_filename_new)
if nargin < 1,  traininglist_filename='training_list10.mat';  end;
if nargin < 2,  model_filename_old='models.mat'; end;
if nargin < 3,  model_filename_new='models.mat'; end;
MIN_SELF_TRANSITION_COUNT=0.00;

load(model_filename_old, 'mean_vec_i_m', 'var_vec_i_m', 'A_i_m');
load(traininglist_filename,'list');

[dim,STATE_NO,MODEL_NO]=size(mean_vec_i_m);

% allocate mean vectors of states of models
vector_sums_i_m=zeros(dim,STATE_NO,MODEL_NO);
var_vec_sums_i_m=zeros(dim,STATE_NO,MODEL_NO);
fr_no_i_m=zeros(STATE_NO,MODEL_NO);
self_tr_fr_no_i_m=zeros(STATE_NO,MODEL_NO);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                          FOR DEBUG,  COV. MATRICES are set to identity matrix                                                %                                                        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for m=1:MODEL_NO
%     for i=1:STATE_NO           
%             var_vec_i_m(:,i,m)= ones(dim,1);        
%     end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

total_log_prob = 0;
total_fr_no = 0;
utterance_no=size(list,1);
for k=1:utterance_no
        filename=list{k,2};
        m=list{k,1}; % word ID 
        fid=fopen(filename,'r');
        fseek(fid, 12, 'bof'); % skip the 12-byte HTK header
        c=fread(fid,'float','b');
        fclose(fid);
        fr_no=length(c)/dim;
        c=reshape(c,dim,fr_no);
        [log_prob, pr_i_t, pr_self_tr_i_t ]=forward_backward_hmm_log_math(c,mean_vec_i_m(:,:,m),var_vec_i_m(:,:,m),A_i_m(:,m));        
        total_log_prob = total_log_prob + log_prob;
        total_fr_no = total_fr_no + fr_no;
        
        for i=1:STATE_NO
              fr_no_i_m(i,m)=fr_no_i_m(i,m)+sum(pr_i_t(i,:));
              self_tr_fr_no_i_m(i,m)=self_tr_fr_no_i_m(i,m)+sum(pr_self_tr_i_t(i,1:end-1));   
              for fr=1:fr_no
                 vector_sums_i_m(:,i,m) = vector_sums_i_m(:,i,m) +  pr_i_t(i,fr)*c(:,fr);
                 var_vec_sums_i_m(:,i,m) =var_vec_sums_i_m(:,i,m) + pr_i_t(i,fr)*(c(:,fr)-mean_vec_i_m(:,i,m)).*(c(:,fr)-mean_vec_i_m(:,i,m));
              end
        end
end %for k=1:utterance_no
        
% model reestimation 
old_mean_vec_i_m=mean_vec_i_m;
old_var_vec_i_m= var_vec_i_m;
old_A_i_m=A_i_m;
for m=1:MODEL_NO
   for i=1:STATE_NO;
         mean_vec_i_m(:,i,m) = vector_sums_i_m(:,i,m)/ fr_no_i_m(i,m);
         var_vec_i_m(:,i,m)= var_vec_sums_i_m(:,i,m) /  fr_no_i_m(i,m);
         A_i_m(i,m)=(self_tr_fr_no_i_m(i,m)+MIN_SELF_TRANSITION_COUNT) /(fr_no_i_m(i,m)+2*MIN_SELF_TRANSITION_COUNT);
   end
end
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                   tying of cov. matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  overall_var_vec=sum(sum(var_vec_sums_i_m(:,:,:),3 ),2)/sum(sum(fr_no_i_m,2 ),1);
%  for m=1:MODEL_NO
%      for i=1:STATE_NO
%          var_vec_i_m(:,i,m)=overall_var_vec;
%      end
%  end
 %%%%%%%%%%%%%%%%            end of cov. matrices tying                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                            variance comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
var_new_to_old_ratio=var_vec_i_m ./ old_var_vec_i_m;
%var_new_to_old_ratio
save(model_filename_new, 'mean_vec_i_m', 'var_vec_i_m', 'A_i_m');
fprintf('re-estimation complete \n');
