
function [log_prob, pr_i_t,  pr_self_tr_i_t ]=forward_backward_hmm_log_math( V, mean_vec_i, var_vec_i, A_i  )
[dim , N]=size(mean_vec_i);
[dim2 , T]=size(V);

[log_prob,  logfw, logObsevation_i_t ]=forward_hmm_log_math(V, mean_vec_i, var_vec_i, A_i );
pr_self_tr_i_t=zeros(N,T);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    log backward function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
logbw=ones(N,T)*(-inf);
t=T;
logbw(N,T)=log(1-A_i(N));
% pr_self_tr_i_t(N)=0;  has been initialized  
for t=T-1:-1:1
    for i=1:N
        if i==N
            logbw(i,t)= log(A_i(i))+ logObsevation_i_t(i,t+1) + logbw(i,t+1);
            pr_self_tr_i_t(i,t)=exp(logfw(i,t)+  log(A_i(i))+ logObsevation_i_t(i,t+1)  + logbw(i,t+1)-log_prob);
        else
            logbw(i,t)=logSum([ (log(A_i(i))+ logObsevation_i_t(i,t+1) + logbw(i,t+1)) , (log(1-(A_i(i))) + logObsevation_i_t(i+1,t+1)+ logbw(i+1,t+1) )] );
            pr_self_tr_i_t(i,t)=exp(logfw(i,t)+ log(A_i(i))+logObsevation_i_t(i,t+1) + logbw(i,t+1)-log_prob);
        end
    end
end


pr_i_t= exp(  logfw+logbw - log_prob );
count_at_t(1:T)=sum(pr_i_t,1);
count_at_t=squeeze(count_at_t);
if  (sum(count_at_t) -T) > 1E-6
    diff=sum(count_at_t) -T ;
end
% t=1;    
% hold off;
% plot(pr_i_t(:,t)); 
% hold on;
% for t=2:T
%     plot(pr_i_t(:,t));
%     pause(0.1);
% end
% count_i=sum(pr_i_t,2);
% stem( count_i );
% hold off;
end % of function


  