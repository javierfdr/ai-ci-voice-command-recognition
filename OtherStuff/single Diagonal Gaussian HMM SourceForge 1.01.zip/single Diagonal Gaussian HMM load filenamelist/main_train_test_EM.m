dr_wav2mfcc_e_d_a_gen;
generate_isolated_digits_ti_training_list_mat;
generate_isolated_digits_ti_testing_list_mat;

MODEL_NO=11;
feature_file_format='htk';
ITERATION_BEGIN=1;
ITERATION_END=5;

for STATE_NO=6:10
    DIM=39;
    model_filename_prefix='models/EM_models';
    traininglist_filename='training_list.mat';
    testinglist_filename='testing_list.mat'; % outside test
    accuracy_filename=sprintf('recog_rate_S%d_EM_outside.mat',STATE_NO);
    
    total_log_prob=zeros(1,ITERATION_END);
    recog_rate_EM_Viterbi=zeros(1,ITERATION_END);
    
    for iter=ITERATION_BEGIN:ITERATION_END
        model_filename_new=[model_filename_prefix, '_S', int2str(STATE_NO), '_iter', int2str(iter),  '.mat'];
        if iter==1
            gau_hmm_init_train(traininglist_filename,model_filename_new,MODEL_NO,STATE_NO,DIM)
        else
            if ( exist(accuracy_filename,'file')  )
                load(accuracy_filename,'recog_rate_EM_Viterbi');
            end
            model_filename_old=[model_filename_prefix, '_S', int2str(STATE_NO), '_iter', int2str(iter-1),  '.mat'];
            total_log_prob(iter)=gau_hmm_EM_reestimation(traininglist_filename,model_filename_old,model_filename_new)
        end
        recog_rate_EM_Viterbi(iter)=gau_hmm_Viterbi_recognition(testinglist_filename,model_filename_new,feature_file_format)
        save(accuracy_filename,'recog_rate_EM_Viterbi');
    end
end

