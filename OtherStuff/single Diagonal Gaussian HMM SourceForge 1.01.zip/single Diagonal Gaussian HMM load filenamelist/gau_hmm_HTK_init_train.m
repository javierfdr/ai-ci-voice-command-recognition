function  gau_dho_hmm_init_train(traininglist_filename,model_filename,HOSTATE_NO,HMM_ORDER, dim )
if nargin < 1,  traininglist_filename='training_list.mat' ; end;
if nargin < 2,  model_filename='models.mat'; end;
if nargin < 3
    HOSTATE_NO=4;
end
if nargin < 4
    HMM_ORDER=3;
end
if nargin < 5
    dim=12;
end

MIN_SELF_TRANSITION_COUNT=1/2;
load(traininglist_filename,'list');
SIL_HOSTATE_NO=1;
MODEL_NO=10;
D=HMM_ORDER;

TOTAL_HOSTATE_NO=HOSTATE_NO+2*SIL_HOSTATE_NO; 

% allocate mean vectors of states of models
vector_sums_i_d_m=zeros(dim,HOSTATE_NO,D,MODEL_NO);
sil_vector_sums_i_d=zeros(dim,SIL_HOSTATE_NO,D);
moment2_matrix_sums_i_d_m=zeros(dim,dim,HOSTATE_NO,D,MODEL_NO);
sil_moment2_matrix_sums_i_d=zeros(dim,dim,SIL_HOSTATE_NO,D);
fr_no_i_d_m=zeros(HOSTATE_NO,D,MODEL_NO);
sil_fr_no_i_d=zeros(SIL_HOSTATE_NO,D);
self_tr_fr_no_i_d_m=zeros(HOSTATE_NO,D,MODEL_NO);
sil_self_tr_fr_no_i_d=zeros(SIL_HOSTATE_NO,D);

total_log_prob = 0;
total_fr_no = 0;
utterance_no=size(list,1);
for k=1:utterance_no
        filename=list{k,2};
        m=list{k,1}; % word ID 
        fid=fopen(filename,'r');
        fseek(fid, 12, 'bof'); % skip the 12-byte HTK header
        c=fread(fid,'float','b');        
        fclose(fid);
        fr_no=length(c)/dim;
        total_fr_no=total_fr_no+fr_no;
        c=reshape(c,dim,fr_no);
        
        % digit part
        for s=SIL_HOSTATE_NO+1:TOTAL_HOSTATE_NO-SIL_HOSTATE_NO
            begin_fr=round(  fr_no*(s-1) /TOTAL_HOSTATE_NO)+1;
            end_fr=round( fr_no*s /TOTAL_HOSTATE_NO);
            seg_length=end_fr-begin_fr+1;
            i=s-SIL_HOSTATE_NO; % i=the ho-state of digit
            if (seg_length > D)
                for d=1:D
                    vector_sums_i_d_m(:,i,d,m) = vector_sums_i_d_m(:,i,d,m) +  c(:,begin_fr+d-1);
                    moment2_matrix_sums_i_d_m(:,:,i,d,m) = moment2_matrix_sums_i_d_m(:,:,i,d,m) +  c(:,begin_fr+d-1)* c(:,begin_fr+d-1)';
                    fr_no_i_d_m(i,d,m)=fr_no_i_d_m(i,d,m)+1;
                    self_tr_fr_no_i_d_m(i,d,m)= self_tr_fr_no_i_d_m(i,d,m) + 1;
                end
                vector_sums_i_d_m(:,i,D,m) = vector_sums_i_d_m(:,i,D,m) +  sum(c(:,begin_fr+D:end_fr),2);
                moment2_matrix_sums_i_d_m(:,:,i,D,m) = moment2_matrix_sums_i_d_m(:,:,i,D,m) +  c(:,begin_fr+D:end_fr)* c(:,begin_fr+D:end_fr)';
                fr_no_i_d_m(i,D,m)=fr_no_i_d_m(i,D,m)+seg_length-D;
                self_tr_fr_no_i_d_m(i,D,m)= self_tr_fr_no_i_d_m(i,D,m) + seg_length-D-1;
            else
               for d=1:seg_length
                    vector_sums_i_d_m(:,i,d,m) = vector_sums_i_d_m(:,i,d,m) +  c(:,begin_fr+d-1);
                    moment2_matrix_sums_i_d_m(:,:,i,d,m) = moment2_matrix_sums_i_d_m(:,:,i,d,m) +  c(:,begin_fr+d-1)* c(:,begin_fr+d-1)';
                    fr_no_i_d_m(i,d,m)=fr_no_i_d_m(i,d,m)+1;
                    self_tr_fr_no_i_d_m(i,d,m)= self_tr_fr_no_i_d_m(i,d,m) + 1;
               end
               self_tr_fr_no_i_d_m(i,d,m)= self_tr_fr_no_i_d_m(i,d,m) - 1; % the seg-last frame transite to next HOSTAT           
            end % if (seg_length)
        end %for s=2:TOTAL_HOSTATE_NO-1
        
        %  begining and ending silence parts
         for s=[1:SIL_HOSTATE_NO   TOTAL_HOSTATE_NO-SIL_HOSTATE_NO+1:TOTAL_HOSTATE_NO]
            begin_fr=round(  fr_no*(s-1) /TOTAL_HOSTATE_NO)+1;
            end_fr=round( fr_no*s /TOTAL_HOSTATE_NO);
            seg_length=end_fr-begin_fr+1;
            i=1; % i=the ho-state of digit
            if (seg_length > D)
                for d=1:D
                    sil_vector_sums_i_d(:,i,d) = sil_vector_sums_i_d(:,i,d) +  c(:,begin_fr+d-1);
                    sil_moment2_matrix_sums_i_d(:,:,i,d) = sil_moment2_matrix_sums_i_d(:,:,i,d) +  c(:,begin_fr+d-1)* c(:,begin_fr+d-1)';
                    sil_fr_no_i_d(i,d)=sil_fr_no_i_d(i,d)+1;
                    sil_self_tr_fr_no_i_d(i,d)= sil_self_tr_fr_no_i_d(i,d) + 1;
                end
                sil_vector_sums_i_d(:,i,D) = sil_vector_sums_i_d(:,i,D) +  sum(c(:,begin_fr+D:end_fr),2);
                sil_moment2_matrix_sums_i_d(:,:,i,D) = sil_moment2_matrix_sums_i_d(:,:,i,D) +  c(:,begin_fr+D:end_fr)* c(:,begin_fr+D:end_fr)';
                sil_fr_no_i_d(i,D)=sil_fr_no_i_d(i,D)+seg_length-D;
                sil_self_tr_fr_no_i_d(i,D)= sil_self_tr_fr_no_i_d(i,D) + seg_length-D-1;
            else
               for d=1:seg_length
                    sil_vector_sums_i_d(:,i,d) = sil_vector_sums_i_d(:,i,d) +  c(:,begin_fr+d-1);
                    sil_moment2_matrix_sums_i_d(:,:,i,d) = sil_moment2_matrix_sums_i_d(:,:,i,d) +  c(:,begin_fr+d-1)* c(:,begin_fr+d-1)';
                    sil_fr_no_i_d(i,d)=sil_fr_no_i_d(i,d)+1;
                    sil_self_tr_fr_no_i_d(i,d)= sil_self_tr_fr_no_i_d(i,d) + 1;
               end
               sil_self_tr_fr_no_i_d(i,d)= sil_self_tr_fr_no_i_d(i,d) - 1; % the seg-last frame transite to next HOSTAT           
            end % if (seg_length > D)
        end %  for s=[1 TOTAL_HOSTATE_NO]
end % for k=1:utterance_no    

A_i_d_m=zeros(HOSTATE_NO,D,MODEL_NO); %self-transition prob.
sil_A_i_d=zeros(SIL_HOSTATE_NO,D); % silence self-transition prob.
mean_vec_i_d_m=zeros(dim,HOSTATE_NO,D,MODEL_NO);
sil_mean_vec_i_d=zeros(dim,SIL_HOSTATE_NO,D);
cov_matrix_i_d_m=zeros(dim,dim,HOSTATE_NO,D,MODEL_NO);
sil_cov_matrix_i_d=zeros(dim,dim,SIL_HOSTATE_NO,D);

for m=1:MODEL_NO
    for i=1:HOSTATE_NO
        for d=1:D
            mean_vec_i_d_m(:,i,d,m) = vector_sums_i_d_m(:,i,d,m) / fr_no_i_d_m(i,d,m);
            cov_matrix_i_d_m(:,:,i,d,m) = moment2_matrix_sums_i_d_m(:,:,i,d,m) / fr_no_i_d_m(i,d,m) - mean_vec_i_d_m(:,i,d,m)*mean_vec_i_d_m(:,i,d,m)';
            A_i_d_m(i,d,m)=(self_tr_fr_no_i_d_m(i,d,m)+MIN_SELF_TRANSITION_COUNT)/(fr_no_i_d_m(i,d,m)+2*MIN_SELF_TRANSITION_COUNT);
        end
    end
end

for i=1:SIL_HOSTATE_NO
        for d=1:D
            sil_mean_vec_i_d(:,i,d) = sil_vector_sums_i_d(:,i,d) / sil_fr_no_i_d(i,d);
            sil_cov_matrix_i_d(:,:,i,d) = sil_moment2_matrix_sums_i_d(:,:,i,d) / sil_fr_no_i_d(i,d) - sil_mean_vec_i_d(:,i,d)*sil_mean_vec_i_d(:,i,d)';
            sil_A_i_d(i,d)=(sil_self_tr_fr_no_i_d(i,d)+MIN_SELF_TRANSITION_COUNT)/(sil_fr_no_i_d(i,d)+2*MIN_SELF_TRANSITION_COUNT);
        end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                   tying of cov. matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 overall_cov_matrix=zeros(dim,dim);
 for i=1:SIL_HOSTATE_NO
     for d=1:D
         overall_cov_matrix=overall_cov_matrix+sil_cov_matrix_i_d(:,:,i,d)*sil_fr_no_i_d(i,d);
     end
 end
 for m=1:MODEL_NO
     for i=1:HOSTATE_NO
         for d=1:D
             overall_cov_matrix=overall_cov_matrix+cov_matrix_i_d_m(:,:,i,d,m)*fr_no_i_d_m(i,d,m);
         end
     end
 end
 overall_cov_matrix=overall_cov_matrix/total_fr_no;
 
  for i=1:SIL_HOSTATE_NO
     for d=1:D
         sil_cov_matrix_i_d(:,:,i,d)= overall_cov_matrix;
     end
 end
 for m=1:MODEL_NO
     for i=1:HOSTATE_NO
         for d=1:D
             cov_matrix_i_d_m(:,:,i,d,m)=overall_cov_matrix;
         end
     end
 end
%%%%%%%%%%%%%%%%            end of cov. matrices tying                   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

save(model_filename, 'mean_vec_i_d_m', 'cov_matrix_i_d_m', 'A_i_d_m', 'sil_mean_vec_i_d', 'sil_cov_matrix_i_d', 'sil_A_i_d');
fprintf('init. train complete \n');



