function [Fopt, Popt]= fun_viterbi_LR_hmm(V, mean_vec, var_vec, A)
if ( nargin ==0 )
    V=[-1  0  2  3  5  -3];
    mean_vec=[-2 , 1 , 4, -1];
    var_vec=[1 , 1 , 1, 1];
    A=[0.5 , 0.5, 0.5, 0.5]
end

[dim ,N]=size(mean_vec);[dim , T]=size(V);
P=cell(N,T);  f=ones(N,T)*(-inf);
for i=1:N
        P{i,1}=i;
end
t=1;i=1;
f(i,t)=logDiagGaussian(V(:,t),mean_vec(:,i),var_vec(:,i));
for t=2:T
    i=1;
        f(i,t)=f(i,t-1)+log(A(i))+ 	logDiagGaussian(V(:,t),mean_vec(:,i),var_vec(:,i) );
        P{i,t}=[P{i,t-1}  i ];
    for i=2:N  % pi=previous i
        [f(i,t), argi] = max(  [ f(i-1,t-1) + log(1-A(i-1))  ,  f(i,t-1) + log(A(i)) ] ); 
        f(i,t)=f(i,t)+logDiagGaussian(V(:,t),mean_vec(:,i),var_vec(:,i) );
        P{i,t}=[P{i+argi-2,t-1}  i ];  
   end
end
Fopt=  f(N,T) + log(1-A(N)) ; 
Popt=  P{N,T} ;
disp('end')

function log_pr=logDiagGaussian(v,u,K)
 dim=length(K);
 log_pr=-1/2*dim*log(2*pi) -1/2*sum(log(K))- 1/2*sum((v-u).*(v-u)./K);
